import Link from "next/link";
import { MessageCircle } from "lucide-react";
import LikeButton from "./LikeButton";
import { timeAgo } from "@/lib/format";
import { publicUrl } from "@/lib/r2";

export type FeedPost = { id: string; caption: string; imageKey: string; createdAt: Date; user: { name: string }; _count: { likes: number; comments: number }; likes: { userId: string }[] };

export default function PostCard({ p, signedIn }: { p: FeedPost; signedIn: boolean }) {
  return (
    <article className="card overflow-hidden">
      <Link href={`/post/${p.id}`} aria-label={`Open post by ${p.user.name}`}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={publicUrl(p.imageKey)} alt={p.caption || `Photo by ${p.user.name}`} loading="lazy" className="aspect-[4/5] w-full bg-neutral-800 object-cover" />
      </Link>
      <div className="p-3">
        <p className="text-sm"><span className="font-medium">{p.user.name}</span> <span className="text-neutral-500">· {timeAgo(p.createdAt)}</span></p>
        {p.caption && <p className="mt-1 line-clamp-2 text-sm text-neutral-300">{p.caption}</p>}
        <div className="mt-1 flex items-center gap-3">
          <LikeButton postId={p.id} signedIn={signedIn} initialCount={p._count.likes} initialLiked={p.likes.length > 0} />
          <Link href={`/post/${p.id}`} className="inline-flex min-h-[44px] items-center gap-1.5 text-sm text-neutral-300 hover:text-white"><MessageCircle className="h-5 w-5" /> {p._count.comments}</Link>
        </div>
      </div>
    </article>
  );
}
