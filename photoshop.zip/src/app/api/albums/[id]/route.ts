import { db } from "@/lib/db";
import { guarded, json, fail } from "@/lib/api";

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  return guarded(req, null, async ({ user }) => {
    const r = await db.album.deleteMany({ where: { id: params.id, userId: user.id } });
    return r.count ? json({ ok: true }) : fail("Not found", 404);
  });
}
