import { z } from "zod";
import { db } from "@/lib/db";
import { guarded, json, fail } from "@/lib/api";

const schema = z.object({ postId: z.string(), action: z.enum(["add", "remove"]) });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  return guarded(req, schema, async ({ user }, b) => {
    const album = await db.album.findUnique({ where: { id: params.id } });
    if (!album || album.userId !== user.id) return fail("Not found", 404);
    if (!(await db.post.findUnique({ where: { id: b.postId } }))) return fail("Post not found", 404);
    if (b.action === "add") await db.albumPost.upsert({ where: { albumId_postId: { albumId: album.id, postId: b.postId } }, create: { albumId: album.id, postId: b.postId }, update: {} });
    else await db.albumPost.deleteMany({ where: { albumId: album.id, postId: b.postId } });
    return json({ ok: true });
  });
}
