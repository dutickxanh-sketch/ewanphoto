import { z } from "zod";
import { db } from "@/lib/db";
import { guarded, json } from "@/lib/api";

const schema = z.object({ title: z.string().trim().min(1, "Title required").max(60), isPublic: z.boolean().default(false) });

export async function POST(req: Request) {
  return guarded(req, schema, async ({ user }, b) => {
    const album = await db.album.create({ data: { userId: user.id, title: b.title, isPublic: b.isPublic } });
    return json({ id: album.id }, 201);
  });
}
