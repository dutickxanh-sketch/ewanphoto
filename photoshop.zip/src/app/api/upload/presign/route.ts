import { z } from "zod";
import { randomUUID } from "crypto";
import { guarded, json, fail, rateLimit } from "@/lib/api";
import { ALLOWED_TYPES, MAX_BYTES, presignUpload } from "@/lib/r2";

const schema = z.object({ contentType: z.string(), size: z.number().int().positive() });

export async function POST(req: Request) {
  return guarded(req, schema, async ({ user }, b) => {
    const ext = ALLOWED_TYPES[b.contentType];
    if (!ext) return fail("Only JPEG, PNG or WebP images are allowed", 415);
    if (b.size > MAX_BYTES) return fail("Image must be 10 MB or smaller", 413);
    if (!rateLimit(`up:${user.id}`, 30, 60_000 * 10)) return fail("Upload limit reached, slow down", 429);
    const key = `uploads/${user.id}/${randomUUID()}.${ext}`;
    return json({ key, uploadUrl: await presignUpload(key, b.contentType) });
  });
}
