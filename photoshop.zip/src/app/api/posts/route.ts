import { z } from "zod";
import { db } from "@/lib/db";
import { guarded, json, fail, rateLimit } from "@/lib/api";

const schema = z.object({ imageKey: z.string().max(200), caption: z.string().trim().max(500).default("") });

export async function POST(req: Request) {
  return guarded(req, schema, async ({ user }, b) => {
    if (!new RegExp(`^uploads/${user.id}/[0-9a-f-]{36}\\.(jpg|png|webp)$`).test(b.imageKey)) return fail("Invalid image", 422);
    if (!rateLimit(`post:${user.id}`, 20, 60_000 * 10)) return fail("Too many posts", 429);
    const post = await db.post.create({ data: { userId: user.id, imageKey: b.imageKey, caption: b.caption } });
    return json({ id: post.id }, 201);
  });
}
