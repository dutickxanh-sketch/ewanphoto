import { z } from "zod";
import { db } from "@/lib/db";
import { guarded, json, fail, rateLimit } from "@/lib/api";

const schema = z.object({ body: z.string().trim().min(1, "Comment is empty").max(500) });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  return guarded(req, schema, async ({ user }, b) => {
    if (!rateLimit(`cm:${user.id}`, 20, 60_000 * 5)) return fail("Too many comments", 429);
    if (!(await db.post.findUnique({ where: { id: params.id }, select: { id: true } }))) return fail("Not found", 404);
    await db.comment.create({ data: { userId: user.id, postId: params.id, body: b.body } });
    return json({ ok: true }, 201);
  });
}
