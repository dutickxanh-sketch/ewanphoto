import { destroySession } from "@/lib/auth";
import { guarded, json } from "@/lib/api";
export async function POST(req: Request) {
  return guarded(req, null, async () => { destroySession(); return json({ ok: true }); }, false);
}
