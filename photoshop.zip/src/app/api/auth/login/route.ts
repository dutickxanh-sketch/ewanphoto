import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { guarded, json, fail, rateLimit, ip } from "@/lib/api";

const schema = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(100) });

export async function POST(req: Request) {
  return guarded(req, schema, async ({ req }, b) => {
    if (!rateLimit(`login:${ip(req)}:${b.email}`, 8, 60_000 * 15)) return fail("Too many attempts, try later", 429);
    const user = await db.user.findUnique({ where: { email: b.email } });
    const ok = user ? await bcrypt.compare(b.password, user.passwordHash) : false;
    if (!user || !ok) return fail("Invalid email or password", 401);
    await createSession(user.id);
    return json({ ok: true });
  }, false);
}
