import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";
import { guarded, json, fail, rateLimit, ip } from "@/lib/api";

const schema = z.object({
  name: z.string().trim().min(2).max(40),
  email: z.string().trim().toLowerCase().email().max(120),
  password: z.string().min(8, "Password must be at least 8 characters").max(100),
});

export async function POST(req: Request) {
  return guarded(req, schema, async ({ req }, b) => {
    if (!rateLimit(`reg:${ip(req)}`, 10, 60_000 * 15)) return fail("Too many attempts", 429);
    if (await db.user.findUnique({ where: { email: b.email } })) return fail("Email already registered", 409);
    const user = await db.user.create({ data: { name: b.name, email: b.email, passwordHash: await bcrypt.hash(b.password, 12) } });
    await createSession(user.id);
    return json({ ok: true });
  }, false);
}
