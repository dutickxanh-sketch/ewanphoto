import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/lib/db";
import { publicUrl } from "@/lib/r2";
export const dynamic = "force-dynamic";

async function load(slug: string) {
  return db.album.findFirst({ where: { shareSlug: slug, isPublic: true }, include: { user: { select: { name: true } }, posts: { include: { post: true }, orderBy: { post: { createdAt: "desc" } } } } });
}
export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const a = await load(params.slug); if (!a) return {};
  return { title: a.title, description: `Album by ${a.user.name}`, alternates: { canonical: `/s/${a.shareSlug}` }, openGraph: { title: a.title, images: a.posts[0] ? [publicUrl(a.posts[0].post.imageKey)] : [] } };
}
export default async function Page({ params }: { params: { slug: string } }) {
  const a = await load(params.slug); if (!a) notFound();
  return (
    <div className="space-y-5">
      <div><h1 className="text-xl font-semibold">{a.title}</h1><p className="text-sm text-neutral-500">by {a.user.name}</p></div>
      {a.posts.length === 0 ? <p className="card p-8 text-center text-neutral-400">This album is empty.</p> : (
        <ul className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {a.posts.map(({ post: p }) => <li key={p.id}><Link href={`/post/${p.id}`}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={publicUrl(p.imageKey)} alt={p.caption || "Album photo"} loading="lazy" className="aspect-square w-full rounded-lg bg-neutral-800 object-cover" /></Link></li>)}
        </ul>
      )}
    </div>
  );
}
