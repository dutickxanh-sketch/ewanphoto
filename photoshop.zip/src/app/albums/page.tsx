import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { NewAlbumForm } from "@/components/AlbumActions";
export const metadata = { title: "My albums", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function Page() {
  const user = await getUser(); if (!user) redirect("/login");
  const albums = await db.album.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, include: { _count: { select: { posts: true } } } });
  return (
    <div className="space-y-5">
      <h1 className="text-xl font-semibold">My albums</h1>
      <NewAlbumForm />
      {albums.length === 0 ? <p className="card p-8 text-center text-neutral-400">No albums yet. Create one above, then save photos from any post.</p> : (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {albums.map((a) => <li key={a.id}><Link href={`/albums/${a.id}`} className="card block p-4 hover:bg-neutral-800"><p className="font-medium">{a.title}</p><p className="text-sm text-neutral-500">{a._count.posts} photos · {a.isPublic ? "Shareable" : "Private"}</p></Link></li>)}
        </ul>
      )}
    </div>
  );
}
