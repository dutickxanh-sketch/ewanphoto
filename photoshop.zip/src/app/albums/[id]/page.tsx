import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { publicUrl } from "@/lib/r2";
import { CopyLink, DeleteAlbum, RemoveFromAlbum } from "@/components/AlbumActions";
export const metadata = { robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function Page({ params }: { params: { id: string } }) {
  const user = await getUser(); if (!user) redirect("/login");
  const album = await db.album.findUnique({ where: { id: params.id }, include: { posts: { include: { post: true }, orderBy: { post: { createdAt: "desc" } } } } });
  if (!album || album.userId !== user.id) notFound();
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-xl font-semibold">{album.title}</h1>
        <div className="flex gap-2">{album.isPublic && <CopyLink slug={album.shareSlug} />}<DeleteAlbum albumId={album.id} /></div>
      </div>
      {album.posts.length === 0 ? <p className="card p-8 text-center text-neutral-400">Empty album. Open a photo and use “Save to album”.</p> : (
        <ul className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {album.posts.map(({ post: p }) => (
            <li key={p.id} className="space-y-2">
              <Link href={`/post/${p.id}`}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={publicUrl(p.imageKey)} alt={p.caption || "Album photo"} loading="lazy" className="aspect-square w-full rounded-lg bg-neutral-800 object-cover" /></Link>
              <RemoveFromAlbum albumId={album.id} postId={p.id} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
