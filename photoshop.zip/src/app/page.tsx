import Link from "next/link";
import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";
import PostCard from "@/components/PostCard";

export const dynamic = "force-dynamic";
const PAGE = 12;

export default async function Home({ searchParams }: { searchParams: { tab?: string; q?: string; page?: string } }) {
  const user = await getUser();
  const tab = searchParams.tab === "new" ? "new" : "trending";
  const q = (searchParams.q ?? "").trim().slice(0, 60);
  const page = Math.max(1, parseInt(searchParams.page ?? "1") || 1);
  const where = {
    ...(q ? { caption: { contains: q, mode: "insensitive" as const } } : {}),
    ...(tab === "trending" ? { createdAt: { gte: new Date(Date.now() - 7 * 864e5) } } : {}),
  };
  const posts = await db.post.findMany({
    where,
    orderBy: tab === "trending" ? [{ likes: { _count: "desc" } }, { comments: { _count: "desc" } }, { createdAt: "desc" }] : { createdAt: "desc" },
    skip: (page - 1) * PAGE, take: PAGE + 1,
    select: { id: true, caption: true, imageKey: true, createdAt: true, user: { select: { name: true } }, _count: { select: { likes: true, comments: true } }, likes: { where: { userId: user?.id ?? "-" }, select: { userId: true } } },
  });
  const more = posts.length > PAGE;
  const qs = (o: Record<string, string>) => "/?" + new URLSearchParams({ tab, ...(q ? { q } : {}), ...o }).toString();

  return (
    <>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-2" role="tablist">
          <Link href={qs({ tab: "trending" })} className={tab === "trending" ? "btn" : "btn-ghost"}>Trending</Link>
          <Link href={qs({ tab: "new" })} className={tab === "new" ? "btn" : "btn-ghost"}>Newest</Link>
        </div>
        <form action="/" className="flex gap-2">
          <input type="hidden" name="tab" value={tab} />
          <label htmlFor="q" className="sr-only">Search captions</label>
          <input id="q" name="q" defaultValue={q} placeholder="Search captions" className="input sm:w-64" />
          <button className="btn-ghost">Search</button>
        </form>
      </div>
      {posts.length === 0 ? (
        <div className="card p-10 text-center text-neutral-400">
          <p>{q ? "No photos match your search." : "No photos yet."}</p>
          <Link href={user ? "/upload" : "/register"} className="btn mt-4">{user ? "Upload the first photo" : "Join and upload"}</Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {posts.slice(0, PAGE).map((p) => <PostCard key={p.id} p={p} signedIn={!!user} />)}
        </div>
      )}
      <div className="mt-6 flex justify-between">
        {page > 1 ? <Link className="btn-ghost" href={qs({ page: String(page - 1) })}>← Previous</Link> : <span />}
        {more && <Link className="btn-ghost" href={qs({ page: String(page + 1) })}>Next →</Link>}
      </div>
    </>
  );
}
