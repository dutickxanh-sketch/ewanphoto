import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { publicUrl } from "@/lib/r2";
import { timeAgo } from "@/lib/format";
import LikeButton from "@/components/LikeButton";
import CommentForm from "@/components/CommentForm";
import AddToAlbum from "@/components/AddToAlbum";
import Link from "next/link";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const p = await db.post.findUnique({ where: { id: params.id }, include: { user: { select: { name: true } } } });
  if (!p) return {};
  const title = p.caption.slice(0, 60) || `Photo by ${p.user.name}`;
  return { title, description: p.caption || title, alternates: { canonical: `/post/${p.id}` }, openGraph: { title, images: [publicUrl(p.imageKey)] } };
}

export default async function Page({ params }: { params: { id: string } }) {
  const user = await getUser();
  const p = await db.post.findUnique({
    where: { id: params.id },
    include: { user: { select: { name: true } }, _count: { select: { likes: true } }, likes: { where: { userId: user?.id ?? "-" } }, comments: { orderBy: { createdAt: "asc" }, take: 100, include: { user: { select: { name: true } } } } },
  });
  if (!p) notFound();
  const albums = user ? await db.album.findMany({ where: { userId: user.id }, select: { id: true, title: true }, orderBy: { createdAt: "desc" } }) : [];
  return (
    <div className="grid gap-6 md:grid-cols-[1fr_340px]">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={publicUrl(p.imageKey)} alt={p.caption || `Photo by ${p.user.name}`} className="card w-full object-contain" />
      <div className="space-y-4">
        <div><p className="font-medium">{p.user.name} <span className="text-sm text-neutral-500">· {timeAgo(p.createdAt)}</span></p>{p.caption && <p className="mt-1 whitespace-pre-wrap text-neutral-300">{p.caption}</p>}</div>
        <LikeButton postId={p.id} signedIn={!!user} initialCount={p._count.likes} initialLiked={p.likes.length > 0} />
        {user && <AddToAlbum postId={p.id} albums={albums} />}
        <section aria-label="Comments" className="space-y-3">
          <h2 className="text-sm font-medium text-neutral-400">{p.comments.length} comments</h2>
          {p.comments.map((c) => <p key={c.id} className="text-sm"><span className="font-medium">{c.user.name}</span> <span className="whitespace-pre-wrap text-neutral-300">{c.body}</span></p>)}
          {user ? <CommentForm postId={p.id} /> : <p className="text-sm text-neutral-500"><Link href="/login" className="text-accent underline">Sign in</Link> to comment.</p>}
        </section>
      </div>
    </div>
  );
}
